package com.vvn.fixflow

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
